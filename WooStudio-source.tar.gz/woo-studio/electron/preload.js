const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('wooStudio', {
  getSettings: () => ipcRenderer.invoke('get-settings'),
  saveSettings: (settings) => ipcRenderer.invoke('save-settings', settings),
  chooseOutputDir: () => ipcRenderer.invoke('choose-output-dir'),
  listWebcams: () => ipcRenderer.invoke('list-webcams'),
  checkFfmpeg: () => ipcRenderer.invoke('check-ffmpeg'),
  getDisplays: () => ipcRenderer.invoke('get-displays'),
  selectRegion: () => ipcRenderer.invoke('select-region'),
  startRecording: (settings) => ipcRenderer.invoke('start-recording', settings),
  stopRecording: () => ipcRenderer.invoke('stop-recording'),
  getRecordingState: () => ipcRenderer.invoke('get-recording-state'),
  listClips: (dir) => ipcRenderer.invoke('list-clips', dir),
  probeVideo: (path) => ipcRenderer.invoke('probe-video', path),
  importVideo: () => ipcRenderer.invoke('import-video'),
  exportClip: (opts) => ipcRenderer.invoke('export-clip', opts),
  onRecordingStarted: (cb) => ipcRenderer.on('recording-started', (_e, d) => cb(d)),
  onRecordingStopped: (cb) => ipcRenderer.on('recording-stopped', (_e, d) => cb(d)),
  onRecordingStatus: (cb) => ipcRenderer.on('recording-status', (_e, d) => cb(d)),
  onRecordingError: (cb) => ipcRenderer.on('recording-error', (_e, d) => cb(d)),
  onRecordingFinished: (cb) => ipcRenderer.on('recording-finished', (_e, d) => cb(d)),
});
