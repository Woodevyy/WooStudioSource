const { spawn, execFileSync } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

const WEBCAM_SIZES = {
  small: { w: 240, h: 135 },
  medium: { w: 360, h: 203 },
  large: { w: 480, h: 270 },
};

class Recorder {
  constructor({ settings, outputPath, onStatus, onError, onFinished }) {
    this.settings = settings;
    this.outputPath = outputPath;
    this.onStatus = onStatus || (() => {});
    this.onError = onError || (() => {});
    this.onFinished = onFinished || (() => {});
    this.process = null;
    this.recording = false;
  }

  static checkFfmpeg() {
    try {
      const version = execFileSync('ffmpeg', ['-version'], { encoding: 'utf8' });
      const match = version.match(/ffmpeg version ([^\s]+)/);
      return { available: true, version: match?.[1] ?? 'unknown' };
    } catch {
      return { available: false, version: null };
    }
  }

  static listWebcams() {
    const platform = process.platform;
    try {
      if (platform === 'linux') {
        const devices = [];
        for (let i = 0; i < 8; i += 1) {
          const dev = `/dev/video${i}`;
          if (fs.existsSync(dev)) {
            devices.push({ id: dev, label: `Camera ${i} (${dev})` });
          }
        }
        return devices;
      }

      if (platform === 'darwin') {
        let stderr = '';
        try {
          execFileSync('ffmpeg', ['-f', 'avfoundation', '-list_devices', 'true', '-i', ''], {
            encoding: 'utf8',
            stdio: ['ignore', 'pipe', 'pipe'],
          });
        } catch (error) {
          stderr = error.stderr?.toString() || '';
        }
        const lines = stderr.split('\n');
        const devices = [];
        let inVideo = false;
        lines.forEach((line) => {
          if (line.includes('AVFoundation video devices')) inVideo = true;
          else if (line.includes('AVFoundation audio devices')) inVideo = false;
          else if (inVideo) {
            const m = line.match(/\[(\d+)\] (.+)/);
            if (m) devices.push({ id: m[1], label: m[2] });
          }
        });
        return devices;
      }

      if (platform === 'win32') {
        const out = execFileSync('ffmpeg', ['-list_devices', 'true', '-f', 'dshow', '-i', 'dummy'], {
          encoding: 'utf8',
          stdio: ['ignore', 'pipe', 'pipe'],
        });
        const text = out || '';
        const devices = [];
        const regex = /"([^"]+)" \(video\)/g;
        let match;
        while ((match = regex.exec(text)) !== null) {
          devices.push({ id: match[1], label: match[1] });
        }
        return devices;
      }
    } catch {
      return [];
    }
    return [];
  }

  isRecording() {
    return this.recording;
  }

  async start() {
    const ffmpeg = Recorder.checkFfmpeg();
    if (!ffmpeg.available) {
      throw new Error(
        'FFmpeg is not installed. Install it to record in 4K (see README).'
      );
    }

    fs.mkdirSync(path.dirname(this.outputPath), { recursive: true });

    const args = this.buildFfmpegArgs();
    this.onStatus({ phase: 'starting', message: 'Starting recorder…' });

    this.process = spawn('ffmpeg', args, {
      stdio: ['pipe', 'pipe', 'pipe'],
    });

    this.recording = true;

    this.process.stderr.on('data', (chunk) => {
      const text = chunk.toString();
      if (text.includes('frame=')) {
        const frameMatch = text.match(/frame=\s*(\d+)/);
        const timeMatch = text.match(/time=(\S+)/);
        this.onStatus({
          phase: 'recording',
          frames: frameMatch ? Number(frameMatch[1]) : null,
          time: timeMatch ? timeMatch[1] : null,
        });
      }
    });

    this.process.on('error', (error) => {
      this.recording = false;
      this.onError(error);
    });

    this.process.on('close', (code) => {
      this.recording = false;
      if (code === 0 || code === 255) {
        this.onFinished({ outputPath: this.outputPath, code });
      } else if (code !== null) {
        this.onError(new Error(`FFmpeg exited with code ${code}`));
      }
    });

    await new Promise((resolve) => setTimeout(resolve, 800));
    if (!this.recording) {
      throw new Error('Recording failed to start. Check FFmpeg permissions.');
    }

    this.onStatus({ phase: 'recording', message: 'Recording…' });
    return true;
  }

  async stop() {
    if (!this.process || !this.recording) {
      return null;
    }

    this.onStatus({ phase: 'stopping', message: 'Finalizing video…' });

    return new Promise((resolve, reject) => {
      const proc = this.process;
      const timeout = setTimeout(() => {
        proc.kill('SIGKILL');
      }, 10000);

      proc.once('close', (code) => {
        clearTimeout(timeout);
        resolve({ outputPath: this.outputPath, code });
      });

      proc.once('error', (error) => {
        clearTimeout(timeout);
        reject(error);
      });

      if (proc.stdin.writable) {
        proc.stdin.write('q');
      } else {
        proc.kill('SIGINT');
      }
    });
  }

  buildFfmpegArgs() {
    const { settings } = this;
    const [targetW, targetH] = settings.resolution.split('x').map(Number);
    const fps = settings.fps || 60;
    const platform = process.platform;
    const args = ['-y', '-hide_banner', '-loglevel', 'info'];

    const inputs = [];
    const filters = [];
    let videoInputIndex = 0;
    let audioInputCount = 0;

    // --- Screen capture input ---
    if (platform === 'linux') {
      const session = process.env.XDG_SESSION_TYPE || '';
      if (session === 'wayland') {
        inputs.push('-thread_queue_size', '512', '-framerate', String(fps), '-f', 'pipewire', '-i', '0');
      } else {
        const display = process.env.DISPLAY || ':0.0';
        inputs.push(
          '-thread_queue_size', '512',
          '-framerate', String(fps),
          '-f', 'x11grab',
          '-draw_mouse', '1',
          '-i', `${display}+0,0`
        );
      }
    } else if (platform === 'darwin') {
      inputs.push(
        '-thread_queue_size', '512',
        '-framerate', String(fps),
        '-f', 'avfoundation',
        '-capture_cursor', '1',
        '-i', '1:none'
      );
    } else if (platform === 'win32') {
      inputs.push(
        '-thread_queue_size', '512',
        '-framerate', String(fps),
        '-f', 'gdigrab',
        '-draw_mouse', '1',
        '-i', 'desktop'
      );
    }

    videoInputIndex = 0;

    // --- Region crop ---
    if (settings.captureMode === 'region' && settings.region) {
      const { x, y, width, height } = settings.region;
      filters.push(`[${videoInputIndex}:v]crop=${width}:${height}:${x}:${y},scale=${targetW}:${targetH}:flags=lanczos[v0]`);
    } else {
      filters.push(`[${videoInputIndex}:v]scale=${targetW}:${targetH}:flags=lanczos[v0]`);
    }

    let currentVideo = 'v0';
    let nextInputIndex = 1;

    // --- Webcam overlay ---
    if (settings.webcamEnabled && settings.webcamDevice) {
      const size = WEBCAM_SIZES[settings.webcamSize] || WEBCAM_SIZES.medium;
      if (platform === 'linux') {
        inputs.push('-f', 'v4l2', '-framerate', '30', '-video_size', `${size.w}x${size.h}`, '-i', settings.webcamDevice);
      } else if (platform === 'darwin') {
        inputs.push('-f', 'avfoundation', '-framerate', '30', '-video_size', `${size.w}x${size.h}`, '-i', settings.webcamDevice);
      } else if (platform === 'win32') {
        inputs.push('-f', 'dshow', '-framerate', '30', '-video_size', `${size.w}x${size.h}`, '-i', `video=${settings.webcamDevice}`);
      }

      const overlayPos = this.getOverlayPosition(settings.webcamPosition, size.w, size.h);
      filters.push(`[${nextInputIndex}:v]scale=${size.w}:${size.h}[wc]`);
      filters.push(`[${currentVideo}][wc]overlay=${overlayPos}[vout]`);
      currentVideo = 'vout';
      nextInputIndex += 1;
    } else {
      filters.push(`[${currentVideo}]null[vout]`);
      currentVideo = 'vout';
    }

    // --- Audio inputs ---
    const audioLabels = [];
    if (settings.recordSystemAudio) {
      if (platform === 'linux') {
        inputs.push('-f', 'pulse', '-i', 'default');
      } else if (platform === 'darwin') {
        inputs.push('-f', 'avfoundation', '-i', ':0');
      } else if (platform === 'win32') {
        inputs.push('-f', 'dshow', '-i', 'audio=virtual-audio-capturer');
      }
      audioLabels.push(`[${nextInputIndex}:a]`);
      nextInputIndex += 1;
      audioInputCount += 1;
    }

    if (settings.recordMic) {
      if (platform === 'linux') {
        inputs.push('-f', 'pulse', '-i', 'default');
      } else if (platform === 'darwin') {
        inputs.push('-f', 'avfoundation', '-i', ':1');
      } else if (platform === 'win32') {
        inputs.push('-f', 'dshow', '-i', 'audio=Microphone');
      }
      audioLabels.push(`[${nextInputIndex}:a]`);
      nextInputIndex += 1;
      audioInputCount += 1;
    }

    args.push(...inputs);

    if (audioInputCount > 1) {
      filters.push(`${audioLabels.join('')}amix=inputs=${audioInputCount}:duration=longest[aout]`);
    } else if (audioInputCount === 1) {
      filters.push(`${audioLabels[0]}anull[aout]`);
    }

    args.push('-filter_complex', filters.join(';'));

    args.push('-map', '[vout]');
    if (audioInputCount > 0) {
      args.push('-map', '[aout]');
    }

    const codec = settings.codec === 'hevc' ? 'libx265' : 'libx264';
    args.push(
      '-c:v', codec,
      '-preset', 'fast',
      '-crf', '18',
      '-pix_fmt', 'yuv420p',
      '-r', String(fps)
    );

    if (audioInputCount > 0) {
      args.push('-c:a', 'aac', '-b:a', '192k');
    }

    args.push('-movflags', '+faststart', this.outputPath);
    return args;
  }

  getOverlayPosition(position, w, h) {
    const margin = 24;
    switch (position) {
      case 'top-left':
        return `${margin}:${margin}`;
      case 'top-right':
        return `W-w-${margin}:${margin}`;
      case 'bottom-left':
        return `${margin}:H-h-${margin}`;
      case 'bottom-right':
      default:
        return `W-w-${margin}:H-h-${margin}`;
    }
  }
}

module.exports = { Recorder };
