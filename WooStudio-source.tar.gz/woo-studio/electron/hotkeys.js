const { globalShortcut } = require('electron');

class HotkeyManager {
  constructor({ toggle, stop, onToggle, onStop }) {
    this.bindings = { toggle, stop };
    this.handlers = { onToggle, onStop };
    this.registered = [];
  }

  register() {
    this.unregisterAll();

    const entries = [
      { accel: this.bindings.toggle, handler: this.handlers.onToggle, name: 'toggle' },
      { accel: this.bindings.stop, handler: this.handlers.onStop, name: 'stop' },
    ];

    entries.forEach(({ accel, handler, name }) => {
      if (!accel) return;
      try {
        const ok = globalShortcut.register(accel, () => {
          handler?.();
        });
        if (ok) {
          this.registered.push(accel);
        } else {
          console.warn(`Failed to register hotkey (${name}): ${accel}`);
        }
      } catch (error) {
        console.warn(`Hotkey error (${name}):`, error.message);
      }
    });
  }

  unregisterAll() {
    this.registered.forEach((accel) => globalShortcut.unregister(accel));
    this.registered = [];
  }
}

module.exports = { HotkeyManager };
