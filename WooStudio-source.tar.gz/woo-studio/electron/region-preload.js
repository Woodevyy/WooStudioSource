const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('regionSelector', {
  confirm: (region) => ipcRenderer.send('region-selected', region),
  cancel: () => ipcRenderer.send('region-cancelled'),
});
