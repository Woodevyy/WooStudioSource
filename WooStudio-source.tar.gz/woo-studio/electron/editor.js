const { spawn, execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');

class VideoEditor {
  static checkFfmpeg() {
    try {
      execFileSync('ffmpeg', ['-version'], { encoding: 'utf8' });
      return true;
    } catch {
      return false;
    }
  }

  static listVideos(dir) {
    if (!dir || !fs.existsSync(dir)) return [];
    return fs
      .readdirSync(dir)
      .filter((f) => /\.(mp4|mkv|webm|mov)$/i.test(f))
      .map((f) => ({ name: f, path: path.join(dir, f) }))
      .sort((a, b) => fs.statSync(b.path).mtime - fs.statSync(a.path).mtime);
  }

  static probe(filePath) {
    const out = execFileSync(
      'ffprobe',
      ['-v', 'quiet', '-print_format', 'json', '-show_format', '-show_streams', filePath],
      { encoding: 'utf8' }
    );
    const data = JSON.parse(out);
    const video = data.streams.find((s) => s.codec_type === 'video');
    const duration = parseFloat(data.format.duration || 0);
    return {
      duration,
      width: video?.width ?? 0,
      height: video?.height ?? 0,
      size: parseInt(data.format.size || 0, 10),
    };
  }

  static exportClip({ inputPath, outputPath, startSec, endSec, format = 'mp4' }) {
    return new Promise((resolve, reject) => {
      const duration = Math.max(0.1, endSec - startSec);
      const args = [
        '-y', '-ss', String(startSec), '-i', inputPath,
        '-t', String(duration), '-c', 'copy', '-movflags', '+faststart', outputPath,
      ];
      if (format === 'gif') {
        args.length = 0;
        args.push(
          '-y', '-ss', String(startSec), '-i', inputPath, '-t', String(Math.min(duration, 15)),
          '-vf', 'fps=15,scale=640:-1:flags=lanczos', '-loop', '0', outputPath
        );
      }
      const proc = spawn('ffmpeg', args);
      proc.on('close', (code) => (code === 0 ? resolve(outputPath) : reject(new Error(`Export failed (${code})`))));
      proc.on('error', reject);
    });
  }
}

module.exports = { VideoEditor };
