const { app, BrowserWindow, ipcMain, dialog, globalShortcut, screen, nativeTheme } = require('electron');
const path = require('path');
const fs = require('fs');
const { Recorder } = require('./recorder');
const { HotkeyManager } = require('./hotkeys');
const { VideoEditor } = require('./editor');

let mainWindow = null;
let regionWindow = null;
let recorder = null;
let hotkeyManager = null;

const isDev = process.env.WOOSTUDIO_DEV === '1';

function getSettingsPath() {
  return path.join(app.getPath('userData'), 'settings.json');
}

function loadSettings() {
  try {
    return JSON.parse(fs.readFileSync(getSettingsPath(), 'utf8'));
  } catch {
    return {
      resolution: '3840x2160',
      fps: 60,
      codec: 'h264',
      outputDir: app.getPath('videos'),
      recordSystemAudio: true,
      recordMic: true,
      webcamEnabled: false,
      webcamDevice: '',
      webcamPosition: 'bottom-right',
      webcamSize: 'medium',
      hotkeyToggle: 'CommandOrControl+Shift+R',
      hotkeyStop: 'CommandOrControl+Shift+S',
      captureMode: 'fullscreen',
      region: null,
    };
  }
}

function saveSettings(settings) {
  fs.mkdirSync(path.dirname(getSettingsPath()), { recursive: true });
  fs.writeFileSync(getSettingsPath(), JSON.stringify(settings, null, 2));
}

function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 980,
    height: 720,
    minWidth: 860,
    minHeight: 640,
    backgroundColor: '#0a0a0f',
    title: 'WooStudio',
    icon: path.join(__dirname, '../assets/logo.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  mainWindow.loadFile(path.join(__dirname, '../src/index.html'));
  nativeTheme.themeSource = 'dark';

  if (isDev) {
    mainWindow.webContents.openDevTools({ mode: 'detach' });
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

function createRegionSelector() {
  return new Promise((resolve, reject) => {
    const display = screen.getPrimaryDisplay();
    const { bounds } = display;

    regionWindow = new BrowserWindow({
      x: bounds.x,
      y: bounds.y,
      width: bounds.width,
      height: bounds.height,
      frame: false,
      transparent: true,
      alwaysOnTop: true,
      skipTaskbar: true,
      resizable: false,
      movable: false,
      fullscreen: true,
      webPreferences: {
        preload: path.join(__dirname, 'region-preload.js'),
        contextIsolation: true,
        nodeIntegration: false,
      },
    });

    regionWindow.setIgnoreMouseEvents(false);
    regionWindow.loadFile(path.join(__dirname, '../src/region-selector.html'));

    ipcMain.once('region-selected', (_event, region) => {
      if (regionWindow) {
        regionWindow.close();
        regionWindow = null;
      }
      resolve(region);
    });

    ipcMain.once('region-cancelled', () => {
      if (regionWindow) {
        regionWindow.close();
        regionWindow = null;
      }
      reject(new Error('Region selection cancelled'));
    });

    regionWindow.on('closed', () => {
      regionWindow = null;
    });
  });
}

function broadcast(channel, payload) {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send(channel, payload);
  }
}

function registerHotkeys(settings) {
  if (hotkeyManager) {
    hotkeyManager.unregisterAll();
  }
  hotkeyManager = new HotkeyManager({
    toggle: settings.hotkeyToggle,
    stop: settings.hotkeyStop,
    onToggle: async () => {
      if (recorder?.isRecording()) {
        await stopRecording();
      } else {
        const current = loadSettings();
        await startRecording(current);
      }
    },
    onStop: async () => {
      if (recorder?.isRecording()) {
        await stopRecording();
      }
    },
  });
  hotkeyManager.register();
}

async function startRecording(settings) {
  if (recorder?.isRecording()) {
    throw new Error('Already recording');
  }

  saveSettings(settings);

  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const outputPath = path.join(
    settings.outputDir,
    `WooStudio-${timestamp}.mp4`
  );

  recorder = new Recorder({
    settings,
    outputPath,
    onStatus: (status) => broadcast('recording-status', status),
    onError: (error) => broadcast('recording-error', { message: error.message }),
    onFinished: (info) => broadcast('recording-finished', info),
  });

  await recorder.start();
  broadcast('recording-started', { outputPath });
}

async function stopRecording() {
  if (!recorder?.isRecording()) {
    return null;
  }
  const result = await recorder.stop();
  recorder = null;
  broadcast('recording-stopped', result);
  return result;
}

app.whenReady().then(() => {
  createMainWindow();
  registerHotkeys(loadSettings());

  ipcMain.handle('get-settings', () => loadSettings());
  ipcMain.handle('save-settings', (_event, settings) => {
    saveSettings(settings);
    registerHotkeys(settings);
    return true;
  });

  ipcMain.handle('choose-output-dir', async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
      properties: ['openDirectory', 'createDirectory'],
      title: 'Choose output folder',
    });
    if (result.canceled || !result.filePaths.length) {
      return null;
    }
    return result.filePaths[0];
  });

  ipcMain.handle('list-webcams', () => Recorder.listWebcams());

  ipcMain.handle('check-ffmpeg', () => Recorder.checkFfmpeg());

  ipcMain.handle('get-displays', () =>
    screen.getAllDisplays().map((d) => ({
      id: d.id,
      label: `Display ${d.id} (${d.size.width}x${d.size.height})`,
      bounds: d.bounds,
      size: d.size,
      scaleFactor: d.scaleFactor,
    }))
  );

  ipcMain.handle('select-region', async () => {
    try {
      return await createRegionSelector();
    } catch (error) {
      return null;
    }
  });

  ipcMain.handle('start-recording', async (_event, settings) => {
    await startRecording(settings);
    return true;
  });

  ipcMain.handle('stop-recording', async () => stopRecording());

  ipcMain.handle('get-recording-state', () => ({
    isRecording: recorder?.isRecording() ?? false,
    outputPath: recorder?.outputPath ?? null,
  }));

  ipcMain.handle('list-clips', (_event, dir) => VideoEditor.listVideos(dir));

  ipcMain.handle('probe-video', (_event, filePath) => VideoEditor.probe(filePath));

  ipcMain.handle('import-video', async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
      properties: ['openFile'],
      filters: [{ name: 'Video', extensions: ['mp4', 'mkv', 'webm', 'mov'] }],
    });
    return result.canceled ? null : result.filePaths[0];
  });

  ipcMain.handle('export-clip', async (_event, opts) => {
    const ext = opts.format === 'gif' ? '.gif' : '.mp4';
    const result = await dialog.showSaveDialog(mainWindow, {
      defaultPath: `WooStudio-edit${ext}`,
      filters: [{ name: opts.format === 'gif' ? 'GIF' : 'MP4', extensions: [opts.format === 'gif' ? 'gif' : 'mp4'] }],
    });
    if (result.canceled) return null;
    return VideoEditor.exportClip({ ...opts, outputPath: result.filePath });
  });

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createMainWindow();
    }
  });
});

app.on('will-quit', () => {
  globalShortcut.unregisterAll();
  if (recorder?.isRecording()) {
    recorder.stop().catch(() => {});
  }
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
