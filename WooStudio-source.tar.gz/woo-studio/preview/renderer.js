const $ = (id) => document.getElementById(id);
let recording = false, timerIv = null, timerStart = 0, currentClip = null, duration = 0;

const els = {
  tabs: document.querySelectorAll('.tab'),
  views: { studio: $('view-studio'), editor: $('view-editor') },
  recordBtn: $('recordBtn'), previewBox: $('previewBox'), timer: $('timer'),
  statusText: $('statusText'), ffmpegBadge: $('ffmpegBadge'),
  resolution: $('resolution'), fps: $('fps'), captureMode: $('captureMode'),
  selectRegionBtn: $('selectRegionBtn'), recordSystemAudio: $('recordSystemAudio'),
  recordMic: $('recordMic'), webcamEnabled: $('webcamEnabled'),
  browseBtn: $('browseBtn'), outputDir: $('outputDir'),
  srcMic: $('srcMic'), srcCam: $('srcCam'),
  openEditorBtn: $('openEditorBtn'), snapshotBtn: $('snapshotBtn'),
  clipList: $('clipList'), importClipBtn: $('importClipBtn'),
  editorVideo: $('editorVideo'), trimStart: $('trimStart'), trimEnd: $('trimEnd'),
  exportMp4Btn: $('exportMp4Btn'), exportGifBtn: $('exportGifBtn'),
};

function switchTab(name) {
  els.tabs.forEach((t) => t.classList.toggle('active', t.dataset.tab === name));
  Object.entries(els.views).forEach(([k, v) => v.classList.toggle('active', k === name));
  if (name === 'editor') loadClips();
}

function formatTime(ms) {
  const s = Math.floor(ms / 1000);
  return [Math.floor(s/3600), Math.floor((s%3600)/60), s%60].map(n=>String(n).padStart(2,'0')).join(':');
}

function readSettings() {
  return {
    resolution: els.resolution.value,
    fps: Number(els.fps.value),
    codec: 'h264',
    outputDir: els.outputDir.dataset.path || '',
    recordSystemAudio: els.recordSystemAudio.checked,
    recordMic: els.recordMic.checked,
    webcamEnabled: els.webcamEnabled.checked,
    webcamDevice: '',
    webcamPosition: 'bottom-right',
    webcamSize: 'medium',
    hotkeyToggle: 'CommandOrControl+Shift+R',
    hotkeyStop: 'CommandOrControl+Shift+S',
    captureMode: els.captureMode.value,
    region: els.outputDir.dataset.region ? JSON.parse(els.outputDir.dataset.region) : null,
  };
}

function setRecording(on) {
  recording = on;
  els.recordBtn.classList.toggle('active', on);
  els.recordBtn.innerHTML = on ? '<span class="dot"></span> Stop Recording' : '<span class="dot"></span> Start Recording';
  els.previewBox.classList.toggle('recording', on);
  els.statusText.textContent = on ? 'Recording' : 'Ready';
  if (on) {
    timerStart = Date.now();
    timerIv = setInterval(() => { els.timer.textContent = formatTime(Date.now() - timerStart); }, 250);
  } else {
    clearInterval(timerIv);
    els.timer.textContent = '00:00:00';
  }
}

async function toggleRecord() {
  if (recording) { await window.wooStudio.stopRecording(); return; }
  const s = readSettings();
  if (!s.outputDir) return alert('Choose an output folder first.');
  if (s.captureMode === 'region' && !s.region) return alert('Pick a region first.');
  try { await window.wooStudio.startRecording(s); } catch (e) { alert(e.message); }
}

async function loadClips() {
  const dir = els.outputDir.dataset.path;
  const clips = await window.wooStudio.listClips(dir);
  els.clipList.innerHTML = clips.map((c,i)=>`<li class="list-item${i===0?' active':''}" data-path="${c.path}">${c.name}</li>`).join('') ||
    '<li class="list-item">No clips yet</li>';
  els.clipList.querySelectorAll('.list-item[data-path]').forEach((li) => {
    li.onclick = () => selectClip(li.dataset.path);
  });
  if (clips[0]) selectClip(clips[0].path);
}

async function selectClip(p) {
  currentClip = p;
  els.editorVideo.src = `file://${p}`;
  const info = await window.wooStudio.probeVideo(p);
  duration = info.duration || 0;
  els.trimStart.max = els.trimEnd.max = Math.floor(duration) || 100;
  els.trimEnd.value = els.trimStart.max;
}

function trimSeconds() {
  const start = Number(els.trimStart.value);
  const end = Number(els.trimEnd.value);
  return { start, end: Math.max(start + 0.5, end) };
}

async function init() {
  if (!window.wooStudio) {
    els.ffmpegBadge.textContent = 'Preview mode';
    els.outputDir.textContent = '~/Videos';
    els.outputDir.dataset.path = '/tmp';
    return;
  }

  const [settings, ffmpeg, webcams, state] = await Promise.all([
    window.wooStudio.getSettings(), window.wooStudio.checkFfmpeg(),
    window.wooStudio.listWebcams(), window.wooStudio.getRecordingState(),
  ]);

  els.resolution.value = settings.resolution || '3840x2160';
  els.fps.value = String(settings.fps || 60);
  els.captureMode.value = settings.captureMode || 'fullscreen';
  els.recordSystemAudio.checked = settings.recordSystemAudio !== false;
  els.recordMic.checked = settings.recordMic !== false;
  els.webcamEnabled.checked = !!settings.webcamEnabled;
  els.outputDir.textContent = settings.outputDir || 'Not set';
  els.outputDir.dataset.path = settings.outputDir || '';
  if (settings.region) els.outputDir.dataset.region = JSON.stringify(settings.region);
  if (webcams[0]) settings.webcamDevice = webcams[0].id;

  els.ffmpegBadge.textContent = ffmpeg.available ? `FFmpeg ${ffmpeg.version}` : 'Install FFmpeg';
  els.ffmpegBadge.className = 'badge ' + (ffmpeg.available ? 'ok' : 'bad');
  if (state.isRecording) setRecording(true);

  els.tabs.forEach((t) => t.onclick = () => switchTab(t.dataset.tab));
  els.recordBtn.onclick = toggleRecord;
  els.openEditorBtn.onclick = () => switchTab('editor');

  els.browseBtn.onclick = async () => {
    const dir = await window.wooStudio.chooseOutputDir();
    if (dir) { els.outputDir.textContent = dir; els.outputDir.dataset.path = dir; await window.wooStudio.saveSettings(readSettings()); }
  };

  els.selectRegionBtn.onclick = async () => {
    const region = await window.wooStudio.selectRegion();
    if (region) { els.outputDir.dataset.region = JSON.stringify(region); els.captureMode.value = 'region'; }
  };

  [els.resolution, els.fps, els.captureMode, els.recordSystemAudio, els.recordMic, els.webcamEnabled].forEach((el) => {
    el.onchange = async () => {
      els.srcMic.hidden = !els.recordMic.checked;
      els.srcCam.hidden = !els.webcamEnabled.checked;
      await window.wooStudio.saveSettings(readSettings());
    };
  });

  els.importClipBtn.onclick = async () => {
    const f = await window.wooStudio.importVideo();
    if (f) selectClip(f);
  };

  els.exportMp4Btn.onclick = async () => {
    if (!currentClip) return alert('Select a clip');
    const { start, end } = trimSeconds();
    try { const out = await window.wooStudio.exportClip({ inputPath: currentClip, startSec: start, endSec: end, format: 'mp4' }); alert('Saved: ' + out); loadClips(); }
    catch (e) { alert(e.message); }
  };

  els.exportGifBtn.onclick = async () => {
    if (!currentClip) return alert('Select a clip');
    const { start, end } = trimSeconds();
    try { const out = await window.wooStudio.exportClip({ inputPath: currentClip, startSec: start, endSec: end, format: 'gif' }); alert('Saved: ' + out); }
    catch (e) { alert(e.message); }
  };

  window.wooStudio.onRecordingStarted(() => setRecording(true));
  window.wooStudio.onRecordingStopped(() => { setRecording(false); loadClips(); });
  window.wooStudio.onRecordingError(({ message }) => { setRecording(false); alert(message); });
}

init();
