# WooStudio — Upload & Distribution Guide

## Project folder (source — upload as `.zip` or `.tar.gz`)

Upload the entire `woo-studio/` folder for developers:

| Extension | What it is |
|-----------|------------|
| `.json` | `package.json` — app config & build scripts |
| `.js` | Electron main process, recorder, editor, hotkeys, UI logic |
| `.html` | App UI + region selector + static preview |
| `.css` | OBS-style purple/black theme |
| `.png` | WooStudio logo (`assets/logo.png`) |
| `.md` | README + this guide |
| `.gitignore` | Git ignore rules |

---

## Pre-built UI preview (no install — open in browser)

Folder: `woo-studio/preview/`

| File | Purpose |
|------|---------|
| `preview/index.html` | Static OBS-style UI mockup |
| `preview/styles.css` | Theme |
| `preview/renderer.js` | Preview mode (buttons show layout only) |
| `preview/assets/logo.png` | Logo |

**Open:** double-click `preview/index.html` or run `npm run preview` → http://localhost:8080

---

## Built app installers (after `npm install` + `npm run build`)

Run on each target OS to generate installers:

```bash
cd woo-studio
npm install
npm run build        # Linux
npm run build:win    # Windows (on Windows or with Wine)
npm run build:mac    # macOS (on Mac only)
```

Output folder: `woo-studio/dist/`

| Extension | Platform | For users |
|-----------|----------|-----------|
| `.AppImage` | Linux | Double-click, no install |
| `.deb` | Linux (Debian/Ubuntu) | `sudo dpkg -i WooStudio*.deb` |
| `.tar.gz` | Linux | Extract and run binary inside |
| `.exe` (NSIS) | Windows | Installer wizard |
| `.exe` (portable) | Windows | Single file, no install |
| `.zip` | Windows / macOS | Extract and run |
| `.dmg` | macOS | Drag to Applications |

---

## User requirements

Users must install **FFmpeg** separately:

- **Linux:** `sudo apt install ffmpeg`
- **macOS:** `brew install ffmpeg`
- **Windows:** Download from https://ffmpeg.org and add to PATH

---

## Quick start (developers)

```bash
cd ~/woo-studio
npm install
npm start
```

---

## File tree

```
woo-studio/
├── assets/logo.png          PNG  — app icon & branding
├── electron/                JS   — backend
├── src/                     HTML/CSS/JS — live app UI
├── preview/                 HTML/CSS/JS — pre-built UI preview
├── dist/                    (after build) installers
├── package.json             JSON
├── README.md                MD
└── DISTRIBUTION.md          MD   — this file
```
