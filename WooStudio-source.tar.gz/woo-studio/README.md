# WooStudio

OBS-style 4K screen recorder + built-in video editor. Purple & black theme.

## Features

- Full screen & region capture · 4K/1080p/720p · 60/30 fps
- System audio + microphone · webcam overlay · global hotkeys
- Built-in editor: trim clips, export MP4 or GIF
- OBS-style layout: Scenes, Sources, Preview, Control bar

## Run

```bash
cd woo-studio
npm install
npm start
```

Requires **FFmpeg** installed on the system.

## Pre-built UI preview

Open `preview/index.html` in any browser (layout demo, no recording).

## Build for users

See **DISTRIBUTION.md** for all file types (.AppImage, .deb, .exe, .dmg, .zip, etc.)

```bash
npm run build      # Linux
npm run build:win  # Windows
npm run build:mac  # macOS
```
