const selection = document.getElementById('selection');

let startX = 0;
let startY = 0;
let dragging = false;
let current = null;

function updateBox(x, y, w, h) {
  selection.style.display = 'block';
  selection.style.left = `${x}px`;
  selection.style.top = `${y}px`;
  selection.style.width = `${w}px`;
  selection.style.height = `${h}px`;
}

document.addEventListener('mousedown', (e) => {
  dragging = true;
  startX = e.clientX;
  startY = e.clientY;
  updateBox(startX, startY, 0, 0);
});

document.addEventListener('mousemove', (e) => {
  if (!dragging) return;
  const x = Math.min(startX, e.clientX);
  const y = Math.min(startY, e.clientY);
  const width = Math.abs(e.clientX - startX);
  const height = Math.abs(e.clientY - startY);
  current = { x, y, width, height };
  updateBox(x, y, width, height);
});

document.addEventListener('mouseup', () => {
  dragging = false;
});

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    window.regionSelector.cancel();
  }
  if (e.key === 'Enter' && current && current.width > 10 && current.height > 10) {
    window.regionSelector.confirm(current);
  }
});
